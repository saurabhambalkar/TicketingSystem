from django.contrib import admin
from .models import Bus, User, Book,Registration

# Register your models here.

admin.site.register(Bus)
admin.site.register(User)
admin.site.register(Book)
class register_admin(admin.ModelAdmin):
        list_display=('name','email','age','phone','amount','order_id','paid')
admin.site.register(Registration,register_admin)

